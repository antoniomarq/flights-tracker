<?php
/**
 * Plugin Name: Flights Tracker
 * Description: Buscador móvil de vuelos con guardado por usuario desde la tabla vuelos_live.
 * Version: 0.3.14
 * Author: Antonio Marquez
 * Text Domain: flights-tracker
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Flights_Tracker_Plugin
{
    private const VERSION = '0.3.14';
    private const LIVE_TABLE = 'vuelos_live';
    private const NONCE_ACTION = 'flights_tracker_nonce';
    private const PER_PAGE = 25;
    private const ARCHIVE_CRON = 'flights_tracker_archive_due_saved';
    private $did_render_title_logo = false;

    public static function init(): void
    {
        $plugin = new self();

        register_activation_hook(__FILE__, [$plugin, 'activate']);
        register_deactivation_hook(__FILE__, [$plugin, 'deactivate']);

        add_action('wp_enqueue_scripts', [$plugin, 'register_assets']);
        add_action('wp_enqueue_scripts', [$plugin, 'enqueue_site_design_assets'], 20);
        add_action('init', [$plugin, 'maybe_upgrade']);
        add_filter('render_block', [$plugin, 'prepend_logo_to_page_title'], 10, 2);
        add_action('wp_footer', [$plugin, 'render_custom_site_footer'], 20);
        add_shortcode('flights_tracker', [$plugin, 'render_tracker_shortcode']);
        add_shortcode('flights_tracker_saved', [$plugin, 'render_saved_shortcode']);
        add_shortcode('flights_tracker_debug', [$plugin, 'render_debug_shortcode']);
        add_shortcode('flights_tracker_user_greeting', [$plugin, 'render_user_greeting_shortcode']);

        add_action('wp_ajax_flights_tracker_search', [$plugin, 'ajax_search']);
        add_action('wp_ajax_nopriv_flights_tracker_search', [$plugin, 'ajax_search']);
        add_action('wp_ajax_flights_tracker_matches', [$plugin, 'ajax_matches']);
        add_action('wp_ajax_nopriv_flights_tracker_matches', [$plugin, 'ajax_matches']);
        add_action('wp_ajax_flights_tracker_save', [$plugin, 'ajax_save']);
        add_action('wp_ajax_flights_tracker_saved', [$plugin, 'ajax_saved']);
        add_action('wp_ajax_flights_tracker_archived', [$plugin, 'ajax_archived']);
        add_action('wp_ajax_flights_tracker_delete_saved', [$plugin, 'ajax_delete_saved']);
        add_action('wp_ajax_flights_tracker_delete_archived', [$plugin, 'ajax_delete_archived']);
        add_action('wp_ajax_flights_tracker_complete_saved', [$plugin, 'ajax_complete_saved']);
        add_action('wp_ajax_flights_tracker_download_saved_pdf', [$plugin, 'download_archived_pdf']);
        add_action('wp_ajax_flights_tracker_download_archived_pdf', [$plugin, 'download_archived_pdf']);
        add_action(self::ARCHIVE_CRON, [$plugin, 'archive_due_saved_items']);
    }

    public function activate(): void
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = $this->saved_table();
        $archive_table = $this->archived_table();
        $charset = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            primary_flight_id bigint(20) unsigned NOT NULL,
            related_flight_id bigint(20) unsigned DEFAULT NULL,
            base_iata char(3) NOT NULL DEFAULT 'AGP',
            registration varchar(20) DEFAULT NULL,
            note varchar(255) DEFAULT NULL,
            completed_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY idx_user_created (user_id, created_at),
            KEY idx_user_completed (user_id, completed_at),
            KEY idx_user_registration (user_id, registration),
            UNIQUE KEY uq_user_pair (user_id, primary_flight_id, related_flight_id)
        ) {$charset};");

        dbDelta("CREATE TABLE {$archive_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            saved_id bigint(20) unsigned DEFAULT NULL,
            base_iata char(3) NOT NULL DEFAULT 'AGP',
            registration varchar(20) DEFAULT NULL,
            airline varchar(120) DEFAULT NULL,
            arrival_flight_number varchar(30) DEFAULT NULL,
            arrival_flight_number_display varchar(20) DEFAULT NULL,
            arrival_route varchar(80) DEFAULT NULL,
            arrival_scheduled_time datetime DEFAULT NULL,
            arrival_real_time datetime DEFAULT NULL,
            arrival_status varchar(120) DEFAULT NULL,
            departure_flight_number varchar(30) DEFAULT NULL,
            departure_flight_number_display varchar(20) DEFAULT NULL,
            departure_route varchar(80) DEFAULT NULL,
            departure_scheduled_time datetime DEFAULT NULL,
            departure_real_time datetime DEFAULT NULL,
            departure_status varchar(120) DEFAULT NULL,
            saved_created_at datetime DEFAULT NULL,
            completed_at datetime DEFAULT NULL,
            archived_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY idx_user_archived (user_id, archived_at),
            KEY idx_user_registration (user_id, registration),
            UNIQUE KEY uq_saved_id (saved_id)
        ) {$charset};");

        if (!wp_next_scheduled(self::ARCHIVE_CRON)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', self::ARCHIVE_CRON);
        }

        update_option('flights_tracker_db_version', self::VERSION, false);
    }

    public function deactivate(): void
    {
        $timestamp = wp_next_scheduled(self::ARCHIVE_CRON);

        if ($timestamp) {
            wp_unschedule_event($timestamp, self::ARCHIVE_CRON);
        }
    }

    public function maybe_upgrade(): void
    {
        if (get_option('flights_tracker_db_version') === self::VERSION) {
            return;
        }

        $this->activate();
    }

    public function register_assets(): void
    {
        $base_url = plugin_dir_url(__FILE__);

        wp_register_style('flights-tracker', $base_url . 'assets/css/flights-tracker.css', [], self::VERSION);
        wp_register_script('flights-tracker', $base_url . 'assets/js/flights-tracker.js', [], self::VERSION, true);
    }

    public function enqueue_site_design_assets(): void
    {
        if (is_admin()) {
            return;
        }

        wp_register_style('flights-tracker-site-design', false, [], self::VERSION);
        wp_enqueue_style('flights-tracker-site-design');
        wp_add_inline_style('flights-tracker-site-design', $this->site_design_css());
    }

    public function prepend_logo_to_page_title(string $block_content, array $block): string
    {
        if (
            is_admin()
            || $this->did_render_title_logo
            || !is_singular()
            || ($block['blockName'] ?? '') !== 'core/post-title'
        ) {
            return $block_content;
        }

        $logo = $this->site_logo_markup('ft-page-logo');

        if ($logo === '') {
            return $block_content;
        }

        $this->did_render_title_logo = true;

        return $logo . $block_content;
    }

    public function render_custom_site_footer(): void
    {
        if (is_admin() || is_feed() || wp_is_json_request()) {
            return;
        }

        printf(
            '<footer class="ft-site-footer" aria-label="%s"><p class="ft-site-footer__text">%s</p></footer>',
            esc_attr__('Pie de página', 'flights-tracker'),
            esc_html(sprintf('© %s Antonio Marquez', wp_date('Y')))
        );
    }

    public function render_tracker_shortcode($atts): string
    {
        $atts = shortcode_atts([
            'base' => 'AGP',
            'refresh' => 60,
            'table' => '',
            'per_page' => self::PER_PAGE,
        ], $atts, 'flights_tracker');

        $base = strtoupper(sanitize_text_field($atts['base']));
        $refresh = max(15, absint($atts['refresh']));
        $table = $this->sanitize_table_name((string) $atts['table']);
        $per_page = max(5, min(50, absint($atts['per_page'])));
        $today = wp_date('Y-m-d');
        $search_id = wp_unique_id('ft-query-');

        $this->enqueue_assets($base, $per_page, $refresh, $table);

        ob_start();
        ?>
        <div class="ft-app" data-ft-app data-base="<?php echo esc_attr($base); ?>" data-per-page="<?php echo esc_attr((string) $per_page); ?>" data-table="<?php echo esc_attr($table); ?>" data-ft-ajax-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" data-ft-nonce="<?php echo esc_attr(wp_create_nonce(self::NONCE_ACTION)); ?>">
            <form class="ft-search" data-ft-search-form>
                <label class="ft-search__label" for="<?php echo esc_attr($search_id); ?>">Buscar vuelo</label>
                <div class="ft-search__row">
                    <input id="<?php echo esc_attr($search_id); ?>" class="ft-search__input" data-ft-query type="search" placeholder="Matricula, vuelo o compania" autocomplete="off">
                    <button class="ft-button ft-button--primary" type="submit">Buscar</button>
                </div>

                <div class="ft-filters">
                    <label>
                        <span>Desde</span>
                        <input type="date" data-ft-date-from value="<?php echo esc_attr($today); ?>">
                    </label>
                    <label>
                        <span>Hasta</span>
                        <input type="date" data-ft-date-to value="<?php echo esc_attr($today); ?>">
                    </label>
                    <label>
                        <span>Tipo</span>
                        <select data-ft-direction>
                            <option value="all">Llegada/salida</option>
                            <option value="arrival">Llegada</option>
                            <option value="departure">Salida</option>
                        </select>
                    </label>
                </div>
            </form>

            <div class="ft-toolbar">
                <span data-ft-summary>Actualizando vuelos...</span>
                <button class="ft-button ft-button--ghost" type="button" data-ft-refresh>Actualizar</button>
            </div>

            <div class="ft-alert" data-ft-alert hidden></div>
            <div class="ft-pagination ft-pagination--top" data-ft-pagination hidden></div>
            <div class="ft-list" data-ft-results></div>
            <div class="ft-pagination" data-ft-pagination hidden></div>

            <div class="ft-modal" data-ft-modal hidden>
                <div class="ft-modal__panel" role="dialog" aria-modal="true" aria-labelledby="ft-modal-title">
                    <button class="ft-modal__close" type="button" data-ft-modal-close aria-label="Cerrar">x</button>
                    <h3 id="ft-modal-title">Guardar vuelo</h3>
                    <p data-ft-modal-intro></p>
                    <div class="ft-match-list" data-ft-match-list></div>
                </div>
            </div>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    public function render_saved_shortcode($atts = []): string
    {
        if (!is_user_logged_in()) {
            return '<div class="ft-app"><div class="ft-empty">Debes iniciar sesion para ver tus vuelos guardados.</div></div>';
        }

        $atts = shortcode_atts(['table' => ''], $atts, 'flights_tracker_saved');
        $table = $this->sanitize_table_name((string) $atts['table']);

        $this->enqueue_assets('AGP', self::PER_PAGE, 60, $table);

        ob_start();
        ?>
        <div class="ft-app" data-ft-saved-app data-table="<?php echo esc_attr($table); ?>" data-ft-ajax-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" data-ft-nonce="<?php echo esc_attr(wp_create_nonce(self::NONCE_ACTION)); ?>">
            <div class="ft-toolbar">
                <span data-ft-saved-summary>Cargando tus vuelos guardados...</span>
                <div class="ft-toolbar__actions">
                    <button class="ft-button ft-button--ghost" type="button" data-ft-saved-refresh>Actualizar</button>
                </div>
            </div>
            <div class="ft-alert" data-ft-alert hidden></div>
            <div class="ft-list" data-ft-saved-results></div>

            <section class="ft-archive-section" aria-labelledby="ft-archived-title">
                <div class="ft-toolbar ft-toolbar--archive">
                    <div>
                        <h3 id="ft-archived-title" class="ft-section-title">Vuelos archivados</h3>
                        <span data-ft-archived-summary>Cargando vuelos archivados...</span>
                    </div>
                    <div class="ft-toolbar__actions">
                        <button class="ft-button ft-button--ghost" type="button" data-ft-archived-refresh>Actualizar</button>
                        <button class="ft-button ft-button--primary" type="button" data-ft-archived-pdf>Descargar PDF</button>
                    </div>
                </div>
                <div class="ft-list" data-ft-archived-results></div>
            </section>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    public function render_user_greeting_shortcode($atts = []): string
    {
        if (!is_user_logged_in()) {
            return '';
        }

        $atts = shortcode_atts([
            'text' => 'Bienvenido',
        ], $atts, 'flights_tracker_user_greeting');

        wp_enqueue_style('flights-tracker');

        $user = wp_get_current_user();
        $name = $this->current_user_display_name($user);
        $label = sanitize_text_field((string) $atts['text']);

        return sprintf(
            '<p class="ft-user-greeting">%s %s</p>',
            esc_html($label ?: 'Bienvenido'),
            esc_html($name)
        );
    }

    public function render_debug_shortcode($atts = []): string
    {
        if (!current_user_can('manage_options')) {
            return '';
        }

        $atts = shortcode_atts(['base' => 'AGP', 'table' => ''], $atts, 'flights_tracker_debug');

        global $wpdb;

        $base = strtoupper(sanitize_text_field($atts['base']));
        $table = $this->live_table((string) $atts['table']);
        $current_db = $wpdb->get_var('SELECT DATABASE()');
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        $first_error = $wpdb->last_error;
        $base_total = null;
        $directions = [];
        $sample = [];

        if ($first_error === '') {
            $base_total = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE base_iata = %s", $base));
            $direction_rows = $wpdb->get_results($wpdb->prepare("SELECT direction, COUNT(*) AS total FROM {$table} WHERE base_iata = %s GROUP BY direction", $base), ARRAY_A);
            $sample = $wpdb->get_results($wpdb->prepare("SELECT id, base_iata, direction, numero_vuelo, aerolinea, registration, hora_programada, hora_real, estado FROM {$table} WHERE base_iata = %s ORDER BY id DESC LIMIT 5", $base), ARRAY_A);

            if (is_array($direction_rows)) {
                foreach ($direction_rows as $row) {
                    $directions[] = ($row['direction'] ?? '-') . ': ' . ($row['total'] ?? '0');
                }
            }
        }

        ob_start();
        ?>
        <div class="ft-app">
            <div class="ft-alert">
                <strong>Diagnostico Flights Tracker</strong><br>
                Base de datos actual de WordPress: <code><?php echo esc_html((string) $current_db); ?></code><br>
                Tabla consultada: <code><?php echo esc_html($table); ?></code><br>
                Base IATA: <code><?php echo esc_html($base); ?></code><br>
                Total tabla: <code><?php echo esc_html($first_error === '' ? (string) $total : 'ERROR'); ?></code><br>
                Total <?php echo esc_html($base); ?>: <code><?php echo esc_html($first_error === '' ? (string) $base_total : 'ERROR'); ?></code><br>
                Direcciones: <code><?php echo esc_html($directions ? implode(', ', $directions) : '-'); ?></code><br>
                Ultimo error SQL: <code><?php echo esc_html($first_error !== '' ? $first_error : 'sin error'); ?></code>
            </div>
            <?php if ($sample) : ?>
                <pre class="ft-debug-pre"><?php echo esc_html(wp_json_encode($sample, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
            <?php endif; ?>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    public function ajax_search(): void
    {
        $this->verify_nonce();

        $filters = [
            'query' => isset($_POST['query']) ? sanitize_text_field(wp_unslash($_POST['query'])) : '',
            'base' => isset($_POST['base']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['base']))) : 'AGP',
            'table' => isset($_POST['table']) ? sanitize_text_field(wp_unslash($_POST['table'])) : '',
            'direction' => isset($_POST['direction']) ? sanitize_text_field(wp_unslash($_POST['direction'])) : 'all',
            'date_from' => isset($_POST['dateFrom']) ? sanitize_text_field(wp_unslash($_POST['dateFrom'])) : wp_date('Y-m-d'),
            'date_to' => isset($_POST['dateTo']) ? sanitize_text_field(wp_unslash($_POST['dateTo'])) : wp_date('Y-m-d'),
            'page' => isset($_POST['page']) ? max(1, absint($_POST['page'])) : 1,
            'per_page' => isset($_POST['perPage']) ? max(5, min(50, absint($_POST['perPage']))) : self::PER_PAGE,
            'offset' => isset($_POST['offset']) && $_POST['offset'] !== '' ? max(0, absint($_POST['offset'])) : null,
            'initial_page' => !empty($_POST['initialPage']),
        ];

        wp_send_json_success($this->find_flights($filters));
    }

    public function ajax_matches(): void
    {
        $this->verify_nonce();

        $flight_id = isset($_POST['flightId']) ? absint($_POST['flightId']) : 0;
        $table = isset($_POST['table']) ? sanitize_text_field(wp_unslash($_POST['table'])) : '';
        $flight = $this->get_flight($flight_id, $table);

        if (!$flight) {
            wp_send_json_error(['message' => 'No se ha encontrado el vuelo.'], 404);
        }

        wp_send_json_success([
            'flight' => $this->format_flight($flight),
            'matches' => array_map([$this, 'format_flight'], $this->find_related_flights($flight, $table)),
            'isLoggedIn' => is_user_logged_in(),
        ]);
    }

    public function ajax_save(): void
    {
        $this->verify_nonce();

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesion para guardar vuelos.'], 401);
        }

        global $wpdb;

        $primary_id = isset($_POST['primaryFlightId']) ? absint($_POST['primaryFlightId']) : 0;
        $related_id = isset($_POST['relatedFlightId']) ? absint($_POST['relatedFlightId']) : 0;
        $table = isset($_POST['table']) ? sanitize_text_field(wp_unslash($_POST['table'])) : '';
        $primary = $this->get_flight($primary_id, $table);
        $related = $related_id ? $this->get_flight($related_id, $table) : null;

        if (!$primary) {
            wp_send_json_error(['message' => 'El vuelo principal no existe.'], 404);
        }

        if ($related_id && !$related) {
            wp_send_json_error(['message' => 'El vuelo relacionado no existe.'], 404);
        }

        if ($related && $primary['registration'] !== $related['registration']) {
            wp_send_json_error(['message' => 'Los vuelos seleccionados no tienen la misma matricula.'], 400);
        }

        $now = current_time('mysql');
        $related_sql = $related_id ? '%d' : 'NULL';
        $params = [get_current_user_id(), $primary_id];

        if ($related_id) {
            $params[] = $related_id;
        }

        array_push($params, $primary['base_iata'], $primary['registration'], $now, $now);

        $inserted = $wpdb->query($wpdb->prepare(
            "INSERT INTO {$this->saved_table()}
                (user_id, primary_flight_id, related_flight_id, base_iata, registration, created_at, updated_at)
             VALUES (%d, %d, {$related_sql}, %s, %s, %s, %s)
             ON DUPLICATE KEY UPDATE updated_at = VALUES(updated_at)",
            $params
        ));

        if ($inserted === false) {
            wp_send_json_error(['message' => 'No se ha podido guardar el vuelo.'], 500);
        }

        $saved_row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->saved_table()}
             WHERE user_id = %d AND primary_flight_id = %d AND " . ($related_id ? 'related_flight_id = %d' : 'related_flight_id IS NULL') . "
             ORDER BY id DESC LIMIT 1",
            $related_id ? [get_current_user_id(), $primary_id, $related_id] : [get_current_user_id(), $primary_id]
        ), ARRAY_A);

        if (is_array($saved_row)) {
            $arrival = null;
            $departure = null;

            foreach ([$primary, $related] as $flight) {
                if (!$flight) {
                    continue;
                }

                if (($flight['direction'] ?? '') === 'arrival') {
                    $arrival = $flight;
                }

                if (($flight['direction'] ?? '') === 'departure') {
                    $departure = $flight;
                }
            }

            $this->upsert_archive_snapshot($saved_row, $arrival, $departure, null);
        }

        wp_send_json_success(['message' => 'Vuelo guardado.']);
    }

    public function ajax_saved(): void
    {
        $this->verify_nonce();

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesion.'], 401);
        }

        $table = isset($_POST['table']) ? sanitize_text_field(wp_unslash($_POST['table'])) : '';
        $this->archive_due_saved_items($table);

        wp_send_json_success([
            'saved' => $this->get_saved_flights($table),
            'serverTime' => wp_date('H:i:s'),
        ]);
    }

    public function ajax_archived(): void
    {
        $this->verify_nonce();

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesion.'], 401);
        }

        wp_send_json_success([
            'archived' => $this->get_archived_flights(200),
            'serverTime' => wp_date('H:i:s'),
        ]);
    }

    public function ajax_delete_saved(): void
    {
        $this->verify_nonce();

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesion.'], 401);
        }

        global $wpdb;

        $saved_id = isset($_POST['savedId']) ? absint($_POST['savedId']) : 0;
        $deleted = $wpdb->delete($this->saved_table(), ['id' => $saved_id, 'user_id' => get_current_user_id()], ['%d', '%d']);

        if ($deleted === false) {
            wp_send_json_error(['message' => 'No se ha podido eliminar.'], 500);
        }

        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->archived_table()} WHERE saved_id = %d AND user_id = %d AND archived_at IS NULL",
            $saved_id,
            get_current_user_id()
        ));

        wp_send_json_success(['message' => 'Vuelo eliminado.']);
    }

    public function ajax_delete_archived(): void
    {
        $this->verify_nonce();

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesion.'], 401);
        }

        global $wpdb;

        $archived_id = isset($_POST['archivedId']) ? absint($_POST['archivedId']) : 0;
        $deleted = $wpdb->delete($this->archived_table(), ['id' => $archived_id, 'user_id' => get_current_user_id()], ['%d', '%d']);

        if ($deleted === false) {
            wp_send_json_error(['message' => 'No se ha podido eliminar el vuelo archivado.'], 500);
        }

        wp_send_json_success(['message' => 'Vuelo archivado eliminado.']);
    }

    public function ajax_complete_saved(): void
    {
        $this->verify_nonce();

        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'Debes iniciar sesion.'], 401);
        }

        global $wpdb;

        $saved_id = isset($_POST['savedId']) ? absint($_POST['savedId']) : 0;
        $completed = isset($_POST['completed']) ? absint($_POST['completed']) : 1;

        $updated = $wpdb->update(
            $this->saved_table(),
            [
                'note' => $completed ? 'done' : null,
                'completed_at' => $completed ? current_time('mysql') : null,
                'updated_at' => current_time('mysql'),
            ],
            [
                'id' => $saved_id,
                'user_id' => get_current_user_id(),
            ],
            ['%s', '%s', '%s'],
            ['%d', '%d']
        );

        if ($updated === false) {
            wp_send_json_error(['message' => 'No se ha podido marcar como realizado.'], 500);
        }

        $wpdb->update(
            $this->archived_table(),
            [
                'completed_at' => $completed ? current_time('mysql') : null,
                'updated_at' => current_time('mysql'),
            ],
            [
                'saved_id' => $saved_id,
                'user_id' => get_current_user_id(),
            ],
            ['%s', '%s'],
            ['%d', '%d']
        );

        wp_send_json_success(['message' => $completed ? 'Vuelo realizado.' : 'Vuelo pendiente.']);
    }

    public function download_archived_pdf(): void
    {
        $nonce = isset($_GET['nonce']) ? sanitize_text_field(wp_unslash($_GET['nonce'])) : '';

        if (!wp_verify_nonce($nonce, self::NONCE_ACTION)) {
            wp_die('Sesion no valida.', '', ['response' => 403]);
        }

        if (!is_user_logged_in()) {
            wp_die('Debes iniciar sesion.', '', ['response' => 401]);
        }

        $items = $this->get_archived_flights(1000);
        $user = wp_get_current_user();
        $filename = 'vuelos-archivados-' . sanitize_file_name($user->user_login ?: 'usuario') . '-' . wp_date('Y-m-d') . '.pdf';
        $pdf = $this->build_archived_flights_pdf($items, $user);

        nocache_headers();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($pdf));
        echo $pdf;
        exit;
    }

    private function enqueue_assets(string $base, int $per_page, int $refresh, string $table = ''): void
    {
        wp_enqueue_style('flights-tracker');
        wp_enqueue_script('flights-tracker');

        wp_localize_script('flights-tracker', 'FlightsTracker', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce(self::NONCE_ACTION),
            'base' => $base,
            'table' => $table,
            'perPage' => $per_page,
            'refreshMs' => $refresh * 1000,
            'isLoggedIn' => is_user_logged_in(),
            'loginUrl' => wp_login_url(get_permalink()),
        ]);
    }

    private function verify_nonce(): void
    {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';

        if (!wp_verify_nonce($nonce, self::NONCE_ACTION)) {
            wp_send_json_error(['message' => 'Sesion no valida. Recarga la pagina.'], 403);
        }
    }

    private function find_flights(array $filters): array
    {
        global $wpdb;

        $table = $this->live_table($filters['table']);
        $where = ['base_iata = %s'];
        $params = [$filters['base']];

        $range = $this->date_range($filters['date_from'], $filters['date_to']);
        $where[] = 'COALESCE(hora_real, hora_programada) >= %s';
        $where[] = 'COALESCE(hora_real, hora_programada) < %s';
        array_push($params, $range['start'], $range['end']);

        if ($filters['direction'] === 'arrival' || $filters['direction'] === 'departure') {
            $where[] = 'direction = %s';
            $params[] = $filters['direction'];
        }

        if ($filters['query'] !== '') {
            $like = '%' . $wpdb->esc_like($filters['query']) . '%';
            $where[] = '(registration LIKE %s OR numero_vuelo LIKE %s OR aerolinea LIKE %s)';
            array_push($params, $like, $like, $like);
        }

        $where_sql = implode(' AND ', $where);
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $params));
        $pages = max(1, (int) ceil($total / $filters['per_page']));
        $page = (int) $filters['page'];
        $offset = null;

        if (!empty($filters['initial_page']) && $this->can_start_from_current_time($filters, $range)) {
            $anchor = $this->initial_page_anchor_time();
            $before_params = array_merge($params, [$anchor]);
            $offset = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table}
                 WHERE {$where_sql}
                 AND COALESCE(hora_real, hora_programada) < %s",
                $before_params
            ));
        } elseif ($filters['offset'] !== null) {
            $offset = (int) $filters['offset'];
        }

        if ($offset !== null) {
            $offset = min(max(0, $offset), max(0, $total - 1));
            $page = (int) floor($offset / (int) $filters['per_page']) + 1;
        } else {
            $page = min(max(1, $page), $pages);
            $offset = ($page - 1) * (int) $filters['per_page'];
        }

        $query_params = array_merge($params, [(int) $filters['per_page'], $offset]);

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table}
             WHERE {$where_sql}
             ORDER BY COALESCE(hora_real, hora_programada), hora_programada, id
             LIMIT %d OFFSET %d",
            $query_params
        ), ARRAY_A);

        return [
            'flights' => is_array($rows) ? array_map([$this, 'format_flight'], $rows) : [],
            'pagination' => [
                'page' => $page,
                'perPage' => (int) $filters['per_page'],
                'offset' => $offset,
                'previousOffset' => max(0, $offset - (int) $filters['per_page']),
                'nextOffset' => min($total, $offset + (int) $filters['per_page']),
                'pages' => $pages,
                'total' => $total,
            ],
            'serverTime' => wp_date('H:i:s'),
            'rangeLabel' => $this->range_label($range),
        ];
    }

    private function get_flight(int $flight_id, string $table_override = ''): ?array
    {
        if (!$flight_id) {
            return null;
        }

        global $wpdb;

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->live_table($table_override)} WHERE id = %d", $flight_id), ARRAY_A);

        return is_array($row) ? $row : null;
    }

    private function find_related_flights(array $flight, string $table_override = ''): array
    {
        $registration = trim((string) ($flight['registration'] ?? ''));

        if ($registration === '') {
            return [];
        }

        global $wpdb;

        $opposite = $flight['direction'] === 'arrival' ? 'departure' : 'arrival';
        $operator = $flight['direction'] === 'arrival' ? '>=' : '<=';
        $order = $flight['direction'] === 'arrival' ? 'ASC' : 'DESC';
        $reference_time = $this->best_time_for_query($flight);

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->live_table($table_override)}
             WHERE base_iata = %s AND direction = %s AND registration = %s AND COALESCE(hora_real, hora_programada) {$operator} %s
             ORDER BY COALESCE(hora_real, hora_programada) {$order}, hora_programada {$order}, id {$order}
             LIMIT 20",
            $flight['base_iata'],
            $opposite,
            $registration,
            $reference_time
        ), ARRAY_A) ?: [];
    }

    private function get_saved_flights(string $table_override = '', int $limit = 200): array
    {
        global $wpdb;

        $saved = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->saved_table()} WHERE user_id = %d ORDER BY created_at DESC LIMIT %d",
            get_current_user_id(),
            $limit
        ), ARRAY_A);

        if (!is_array($saved)) {
            return [];
        }

        $items = [];

        foreach ($saved as $row) {
            $primary = $this->get_flight((int) $row['primary_flight_id'], $table_override);
            $related = !empty($row['related_flight_id']) ? $this->get_flight((int) $row['related_flight_id'], $table_override) : null;

            if (!$primary) {
                continue;
            }

            $formatted_primary = $this->format_flight($primary);
            $formatted_related = $related ? $this->format_flight($related) : null;
            $arrival = $formatted_primary['direction'] === 'arrival' ? $formatted_primary : null;
            $departure = $formatted_primary['direction'] === 'departure' ? $formatted_primary : null;

            if ($formatted_related) {
                if ($formatted_related['direction'] === 'arrival') {
                    $arrival = $formatted_related;
                }

                if ($formatted_related['direction'] === 'departure') {
                    $departure = $formatted_related;
                }
            }

            $items[] = [
                'id' => (int) $row['id'],
                'createdAt' => $this->format_local_datetime($row['created_at']),
                'completed' => (string) ($row['note'] ?? '') === 'done' || !empty($row['completed_at']),
                'completedAt' => $this->format_local_datetime($row['completed_at'] ?? null),
                'primary' => $formatted_primary,
                'related' => $formatted_related,
                'arrival' => $arrival,
                'departure' => $departure,
            ];
        }

        return $items;
    }

    public function archive_due_saved_items(string $table_override = ''): void
    {
        global $wpdb;

        $saved = $wpdb->get_results(
            "SELECT * FROM {$this->saved_table()} ORDER BY created_at ASC LIMIT 500",
            ARRAY_A
        );

        if (!is_array($saved)) {
            return;
        }

        foreach ($saved as $row) {
            $saved_id = (int) $row['id'];
            $snapshot = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$this->archived_table()} WHERE saved_id = %d LIMIT 1",
                $saved_id
            ), ARRAY_A);

            if (is_array($snapshot) && !empty($snapshot['archived_at'])) {
                $wpdb->delete($this->saved_table(), ['id' => $saved_id], ['%d']);
                continue;
            }

            $flights = $this->saved_row_flights($row, $table_override);
            $departure = $flights['departure'];

            if (!$departure) {
                $snapshot_timestamp = is_array($snapshot) ? $this->snapshot_departure_timestamp($snapshot) : null;

                if ($snapshot_timestamp && time() >= $snapshot_timestamp + HOUR_IN_SECONDS) {
                    $updated = $wpdb->update(
                        $this->archived_table(),
                        [
                            'completed_at' => $this->datetime_or_null($row['completed_at'] ?? null),
                            'archived_at' => current_time('mysql'),
                            'updated_at' => current_time('mysql'),
                        ],
                        ['saved_id' => $saved_id],
                        ['%s', '%s', '%s'],
                        ['%d']
                    );

                    if ($updated !== false) {
                        $wpdb->delete($this->saved_table(), ['id' => $saved_id], ['%d']);
                    }
                }

                continue;
            }

            $departure_timestamp = $this->archive_departure_timestamp($departure);

            if (!$departure_timestamp || time() < $departure_timestamp + HOUR_IN_SECONDS) {
                $this->upsert_archive_snapshot($row, $flights['arrival'], $departure, null);
                continue;
            }

            $archived = $this->archive_saved_row($row, $flights['arrival'], $departure);

            if ($archived) {
                $wpdb->delete($this->saved_table(), ['id' => $saved_id], ['%d']);
            }
        }
    }

    private function saved_row_flights(array $row, string $table_override = ''): array
    {
        $primary = $this->get_flight((int) $row['primary_flight_id'], $table_override);
        $related = !empty($row['related_flight_id']) ? $this->get_flight((int) $row['related_flight_id'], $table_override) : null;
        $arrival = null;
        $departure = null;

        foreach ([$primary, $related] as $flight) {
            if (!$flight) {
                continue;
            }

            if (($flight['direction'] ?? '') === 'arrival') {
                $arrival = $flight;
            }

            if (($flight['direction'] ?? '') === 'departure') {
                $departure = $flight;
            }
        }

        return [
            'primary' => $primary,
            'related' => $related,
            'arrival' => $arrival,
            'departure' => $departure,
        ];
    }

    private function archive_saved_row(array $row, ?array $arrival, array $departure): bool
    {
        return $this->upsert_archive_snapshot($row, $arrival, $departure, current_time('mysql'));
    }

    private function upsert_archive_snapshot(array $row, ?array $arrival, ?array $departure, ?string $archived_at): bool
    {
        global $wpdb;

        $now = current_time('mysql');
        $base_iata = (string) ($departure['base_iata'] ?? $arrival['base_iata'] ?? $row['base_iata'] ?? 'AGP');
        $registration = (string) ($departure['registration'] ?? $arrival['registration'] ?? $row['registration'] ?? '');
        $airline = (string) ($departure['aerolinea'] ?? $arrival['aerolinea'] ?? '');

        $data = [
            'user_id' => (int) $row['user_id'],
            'saved_id' => (int) $row['id'],
            'base_iata' => $base_iata,
            'registration' => $registration,
            'airline' => $airline,
            'arrival_flight_number' => $arrival ? (string) ($arrival['numero_vuelo'] ?? '') : null,
            'arrival_flight_number_display' => $arrival ? $this->short_flight_number((string) ($arrival['numero_vuelo'] ?? '')) : null,
            'arrival_route' => $arrival ? $this->route_label($arrival) : null,
            'arrival_scheduled_time' => $arrival ? $this->datetime_or_null($arrival['hora_programada'] ?? null) : null,
            'arrival_real_time' => $arrival ? $this->datetime_or_null($arrival['hora_real'] ?? null) : null,
            'arrival_status' => $arrival ? (string) ($arrival['estado'] ?? '') : null,
            'departure_flight_number' => $departure ? (string) ($departure['numero_vuelo'] ?? '') : null,
            'departure_flight_number_display' => $departure ? $this->short_flight_number((string) ($departure['numero_vuelo'] ?? '')) : null,
            'departure_route' => $departure ? $this->route_label($departure) : null,
            'departure_scheduled_time' => $departure ? $this->datetime_or_null($departure['hora_programada'] ?? null) : null,
            'departure_real_time' => $departure ? $this->datetime_or_null($departure['hora_real'] ?? null) : null,
            'departure_status' => $departure ? (string) ($departure['estado'] ?? '') : null,
            'saved_created_at' => $this->datetime_or_null($row['created_at'] ?? null),
            'completed_at' => $this->datetime_or_null($row['completed_at'] ?? null),
            'archived_at' => $this->datetime_or_null($archived_at),
            'updated_at' => $now,
        ];

        $existing_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->archived_table()} WHERE saved_id = %d LIMIT 1",
            (int) $row['id']
        ));

        $formats = ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'];

        if ($existing_id) {
            $updated = $wpdb->update(
                $this->archived_table(),
                $data,
                ['id' => $existing_id],
                $formats,
                ['%d']
            );

            return $updated !== false;
        }

        $data['created_at'] = $now;
        $formats[] = '%s';

        $inserted = $wpdb->insert(
            $this->archived_table(),
            $data,
            $formats
        );

        return $inserted !== false;
    }

    private function get_archived_flights(int $limit = 200): array
    {
        global $wpdb;

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->archived_table()} WHERE user_id = %d AND archived_at IS NOT NULL ORDER BY archived_at DESC LIMIT %d",
            get_current_user_id(),
            $limit
        ), ARRAY_A);

        if (!is_array($rows)) {
            return [];
        }

        return array_map([$this, 'format_archived_item'], $rows);
    }

    private function format_archived_item(array $row): array
    {
        $arrival = $this->format_archived_flight($row, 'arrival');
        $departure = $this->format_archived_flight($row, 'departure');

        return [
            'id' => (int) $row['id'],
            'flightDate' => $this->archived_flight_date($row),
            'createdAt' => $this->format_local_datetime($row['saved_created_at'] ?? null),
            'archivedAt' => $this->format_local_datetime($row['archived_at'] ?? null),
            'completed' => !empty($row['completed_at']),
            'completedAt' => $this->format_local_datetime($row['completed_at'] ?? null),
            'airline' => (string) ($row['airline'] ?? ''),
            'registration' => (string) ($row['registration'] ?? ''),
            'primary' => $arrival ?: $departure,
            'related' => $arrival && $departure ? $departure : null,
            'arrival' => $arrival,
            'departure' => $departure,
        ];
    }

    private function archived_flight_date(array $row): string
    {
        $candidates = [
            $row['departure_real_time'] ?? null,
            $row['departure_scheduled_time'] ?? null,
            $row['arrival_real_time'] ?? null,
            $row['arrival_scheduled_time'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            $timestamp = $this->raw_datetime_timestamp($candidate);

            if ($timestamp) {
                return wp_date('d/m/y', $timestamp);
            }
        }

        return '-';
    }

    private function format_archived_flight(array $row, string $direction): ?array
    {
        $flight_number = (string) ($row[$direction . '_flight_number'] ?? '');
        $route = (string) ($row[$direction . '_route'] ?? '');
        $scheduled = $row[$direction . '_scheduled_time'] ?? null;
        $real = $row[$direction . '_real_time'] ?? null;
        $status = (string) ($row[$direction . '_status'] ?? '');

        if ($flight_number === '' && $route === '' && !$scheduled && !$real && $status === '') {
            return null;
        }

        return [
            'id' => 0,
            'baseIata' => (string) ($row['base_iata'] ?? ''),
            'direction' => $direction,
            'directionLabel' => $direction === 'arrival' ? 'Llegada' : 'Salida',
            'flightNumber' => $flight_number,
            'flightNumberDisplay' => (string) ($row[$direction . '_flight_number_display'] ?? '') ?: $this->short_flight_number($flight_number),
            'airline' => (string) ($row['airline'] ?? ''),
            'origin' => '',
            'destination' => '',
            'route' => $route,
            'scheduledTime' => $this->format_datetime($scheduled),
            'realTime' => $this->format_datetime($real),
            'status' => $status,
            'statusType' => $this->status_type($status),
            'aircraftType' => '',
            'registration' => (string) ($row['registration'] ?? ''),
            'lastSeenAt' => '',
        ];
    }

    private function build_archived_flights_pdf(array $items, WP_User $user): string
    {
        $rows = [];

        foreach ($items as $item) {
            $arrival = $item['arrival'] ?? null;
            $departure = $item['departure'] ?? null;
            $registration = $item['registration'] ?? $arrival['registration'] ?? $departure['registration'] ?? $item['primary']['registration'] ?? '-';
            $airline = $item['airline'] ?? $arrival['airline'] ?? $departure['airline'] ?? '-';
            $route_parts = array_filter([
                $arrival ? $arrival['route'] : '',
                $departure ? $departure['route'] : '',
            ]);

            $rows[] = [
                'flightDate' => $item['flightDate'] ?? '-',
                'completed' => !empty($item['completedAt']) ? $item['completedAt'] : '-',
                'registration' => $registration ?: '-',
                'airline' => $airline ?: '-',
                'arrival' => $arrival ? ($arrival['flightNumberDisplay'] ?: $arrival['flightNumber'] ?: '-') : '-',
                'arrivalTimes' => $this->pdf_time_pair($arrival),
                'departure' => $departure ? ($departure['flightNumberDisplay'] ?: $departure['flightNumber'] ?: '-') : '-',
                'departureTimes' => $this->pdf_time_pair($departure),
                'route' => $route_parts ? implode(' / ', $route_parts) : '-',
                'archived' => $item['archivedAt'] ?? '-',
            ];
        }

        return $this->render_saved_flights_table_pdf($rows, $user, count($items));
    }

    private function pdf_time_pair(?array $flight): string
    {
        if (!$flight) {
            return '-';
        }

        return $this->pdf_time_value($flight['scheduledTime'] ?? '') . '/' . $this->pdf_time_value($flight['realTime'] ?? '');
    }

    private function pdf_time_value(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '-';
        }

        $parts = preg_split('/\s+/', $value);

        return $parts ? end($parts) : $value;
    }

    private function render_saved_flights_table_pdf(array $rows, WP_User $user, int $total): string
    {
        $width = 842;
        $height = 595;
        $margin = 32;
        $table_width = $width - ($margin * 2);
        $header_height = 22;
        $row_height = 38;
        $bottom = 42;
        $columns = [
            ['label' => 'Fecha', 'key' => 'flightDate', 'width' => 54],
            ['label' => 'Realizado', 'key' => 'completed', 'width' => 66],
            ['label' => 'Matricula', 'key' => 'registration', 'width' => 58],
            ['label' => 'Compania', 'key' => 'airline', 'width' => 86],
            ['label' => 'Llegada', 'key' => 'arrival', 'width' => 48],
            ['label' => 'Llegada/real', 'key' => 'arrivalTimes', 'width' => 74],
            ['label' => 'Salida', 'key' => 'departure', 'width' => 48],
            ['label' => 'Salida/real', 'key' => 'departureTimes', 'width' => 74],
            ['label' => 'Ruta', 'key' => 'route', 'width' => 190],
            ['label' => 'Archivado', 'key' => 'archived', 'width' => 80],
        ];
        $title = 'Vuelos archivados';
        $user_name = $this->normalize_pdf_text($user->display_name ?: $user->user_login ?: 'Usuario');
        $generated = wp_date('d/m/Y H:i');
        $pages = [];
        $page_rows = [];
        $table_top = 470;
        $y = $table_top - $header_height;

        foreach ($rows as $row) {
            if ($y - $row_height < $bottom) {
                $pages[] = $page_rows;
                $page_rows = [];
                $y = $table_top - $header_height;
            }

            $page_rows[] = $row;
            $y -= $row_height;
        }

        if ($page_rows || !$pages) {
            $pages[] = $page_rows;
        }

        $objects = [];
        $objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[] = '';
        $page_refs = [];
        $content_object_number = 3 + count($pages);
        $regular_font_object_number = 3 + (count($pages) * 2);
        $bold_font_object_number = $regular_font_object_number + 1;

        foreach ($pages as $index => $page_rows_for_page) {
            $page_refs[] = (string) (3 + $index) . ' 0 R';
            $objects[] = sprintf(
                '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %d %d] /Resources << /Font << /F1 %d 0 R /F2 %d 0 R >> >> /Contents %d 0 R >>',
                $width,
                $height,
                $regular_font_object_number,
                $bold_font_object_number,
                $content_object_number + $index
            );
        }

        foreach ($pages as $page_index => $page_rows_for_page) {
            $stream = '';
            $stream .= $this->pdf_rect(0, 0, $width, $height, '1 1 1');
            $stream .= $this->pdf_text($title, $margin, $height - 42, 20, 'F2', '0.10 0.14 0.20');
            $stream .= $this->pdf_text('Registro fijo para impresion: los vuelos archivados ya no se sincronizan con la tabla live.', $margin, $height - 62, 8.5, 'F1', '0.34 0.39 0.46');
            $stream .= $this->pdf_text('Usuario: ' . $user_name, $width - 300, $height - 42, 9, 'F2', '0.10 0.14 0.20');
            $stream .= $this->pdf_text('Generado: ' . $generated, $width - 300, $height - 58, 8, 'F1', '0.34 0.39 0.46');
            $stream .= $this->pdf_line($margin, $height - 78, $width - $margin, $height - 78, '0.78 0.82 0.87', 0.8);

            $stream .= $this->pdf_rect($margin, $height - 124, 150, 30, '0.96 0.97 0.98');
            $stream .= $this->pdf_text('Total archivados', $margin + 10, $height - 106, 8, 'F1', '0.34 0.39 0.46');
            $stream .= $this->pdf_text((string) $total, $margin + 112, $height - 107, 13, 'F2', '0.10 0.14 0.20');

            $stream .= $this->pdf_rect($margin, $table_top - $header_height, $table_width, $header_height, '0.90 0.92 0.95');

            $x = $margin;
            foreach ($columns as $column) {
                $stream .= $this->pdf_text($column['label'], $x + 5, $table_top - 15, 7.2, 'F2', '0.15 0.19 0.26');
                $x += $column['width'];
            }

            if (!$rows) {
                $stream .= $this->pdf_rect($margin, $table_top - $header_height - 54, $table_width, 54, '1 1 1');
                $stream .= $this->pdf_text('No hay vuelos archivados.', $margin + 14, $table_top - $header_height - 31, 10, 'F1', '0.39 0.46 0.54');
            }

            $row_y = $table_top - $header_height - $row_height;
            foreach ($page_rows_for_page as $row_index => $row) {
                $fill = $row_index % 2 === 0 ? '1 1 1' : '0.98 0.98 0.99';
                $stream .= $this->pdf_rect($margin, $row_y, $table_width, $row_height, $fill);
                $stream .= $this->pdf_line($margin, $row_y, $margin + $table_width, $row_y, '0.84 0.86 0.89', 0.4);

                $x = $margin;
                foreach ($columns as $column) {
                    $value = (string) ($row[$column['key']] ?? '-');
                    $font = in_array($column['key'], ['registration', 'arrival', 'departure'], true) ? 'F2' : 'F1';
                    $color = '0.12 0.18 0.25';
                    $max_lines = in_array($column['key'], ['route', 'airline'], true) ? 2 : 1;
                    $stream .= $this->pdf_cell_text($value, $x + 5, $row_y + $row_height - 12, $column['width'] - 10, 6.6, $font, $color, $max_lines);
                    $x += $column['width'];
                }

                $row_y -= $row_height;
            }

            $stream .= $this->pdf_text('Pagina ' . ($page_index + 1) . ' de ' . count($pages), $width - 92, 24, 8, 'F1', '0.39 0.46 0.54');
            $objects[] = "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "endstream";
        }

        $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $objects[1] = '<< /Type /Pages /Kids [' . implode(' ', $page_refs) . '] /Count ' . count($pages) . ' >>';

        $pdf = "%PDF-1.4\n";
        $offsets = [0];

        foreach ($objects as $index => $object) {
            $offsets[] = strlen($pdf);
            $pdf .= ($index + 1) . " 0 obj\n" . $object . "\nendobj\n";
        }

        $xref_offset = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";

        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\n";
        $pdf .= "startxref\n" . $xref_offset . "\n%%EOF";

        return $pdf;
    }

    private function pdf_cell_text(string $text, float $x, float $y, float $width, float $size, string $font, string $color, int $max_lines = 1): string
    {
        $max_chars = max(4, (int) floor($width / ($size * 0.48)));
        $lines = explode("\n", wordwrap($this->normalize_pdf_text($text), $max_chars, "\n", true));
        $lines = array_slice($lines, 0, $max_lines);

        if (!$lines) {
            $lines = ['-'];
        }

        $stream = '';

        foreach ($lines as $index => $line) {
            $suffix = $index === $max_lines - 1 && count(explode("\n", wordwrap($this->normalize_pdf_text($text), $max_chars, "\n", true))) > $max_lines ? '...' : '';
            $stream .= $this->pdf_text(rtrim($line) . $suffix, $x, $y - ($index * ($size + 2)), $size, $font, $color);
        }

        return $stream;
    }

    private function pdf_text(string $text, float $x, float $y, float $size, string $font = 'F1', string $color = '0 0 0'): string
    {
        return sprintf(
            "BT\n/%s %.2F Tf\n%s rg\n1 0 0 1 %.2F %.2F Tm\n(%s) Tj\nET\n",
            $font,
            $size,
            $color,
            $x,
            $y,
            $this->escape_pdf_text($this->normalize_pdf_text($text))
        );
    }

    private function pdf_rect(float $x, float $y, float $width, float $height, string $fill): string
    {
        return sprintf("q\n%s rg\n%.2F %.2F %.2F %.2F re\nf\nQ\n", $fill, $x, $y, $width, $height);
    }

    private function pdf_line(float $x1, float $y1, float $x2, float $y2, string $stroke, float $width = 1): string
    {
        return sprintf("q\n%s RG\n%.2F w\n%.2F %.2F m\n%.2F %.2F l\nS\nQ\n", $stroke, $width, $x1, $y1, $x2, $y2);
    }

    private function normalize_pdf_text(string $text): string
    {
        $text = remove_accents($text);
        $text = str_replace(['→', '·'], ['->', '-'], $text);

        return preg_replace('/[^\x20-\x7E]/', '', $text) ?: '';
    }

    private function escape_pdf_text(string $text): string
    {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $text);
    }

    private function format_flight(array $row): array
    {
        $direction = (string) ($row['direction'] ?? '');
        $flight_number = (string) ($row['numero_vuelo'] ?? '');

        return [
            'id' => (int) $row['id'],
            'baseIata' => (string) ($row['base_iata'] ?? ''),
            'direction' => $direction,
            'directionLabel' => $direction === 'arrival' ? 'Llegada' : 'Salida',
            'flightNumber' => $flight_number,
            'flightNumberDisplay' => $this->short_flight_number($flight_number),
            'airline' => (string) ($row['aerolinea'] ?? ''),
            'origin' => (string) ($row['origen'] ?? ''),
            'destination' => (string) ($row['destino'] ?? ''),
            'route' => $this->route_label($row),
            'scheduledTime' => $this->format_datetime($row['hora_programada'] ?? null),
            'realTime' => $this->format_datetime($row['hora_real'] ?? null),
            'status' => (string) ($row['estado'] ?? ''),
            'statusType' => $this->status_type((string) ($row['estado'] ?? '')),
            'aircraftType' => (string) ($row['aircraft_type'] ?? ''),
            'registration' => (string) ($row['registration'] ?? ''),
            'lastSeenAt' => $this->format_datetime($row['last_seen_at'] ?? null),
        ];
    }

    private function route_label(array $row): string
    {
        $base = (string) ($row['base_iata'] ?? '');

        if (($row['direction'] ?? '') === 'arrival') {
            return trim((string) ($row['origen'] ?? '')) . ' -> ' . $base;
        }

        return $base . ' -> ' . trim((string) ($row['destino'] ?? ''));
    }

    private function short_flight_number(string $flight_number): string
    {
        preg_match_all('/\d+/', $flight_number, $matches);
        $digits = implode('', $matches[0] ?? []);

        if ($digits === '') {
            return $flight_number;
        }

        return substr($digits, -4);
    }

    private function current_user_display_name(WP_User $user): string
    {
        $name = trim((string) $user->first_name);

        if ($name === '') {
            $name = trim((string) $user->display_name);
        }

        if ($name === '') {
            $name = trim((string) $user->user_login);
        }

        if ($name === '') {
            return 'Usuario';
        }

        if (function_exists('mb_convert_case')) {
            return mb_convert_case($name, MB_CASE_TITLE, 'UTF-8');
        }

        return ucwords(strtolower($name));
    }

    private function status_type(string $status): string
    {
        $status = strtolower($status);

        if (strpos($status, 'landed') === 0) {
            return 'landed';
        }

        if (strpos($status, 'departed') === 0) {
            return 'departed';
        }

        if (strpos($status, 'delayed') === 0) {
            return 'delayed';
        }

        if (strpos($status, 'estimated') === 0) {
            return 'estimated';
        }

        if (strpos($status, 'scheduled') === 0) {
            return 'scheduled';
        }

        return 'unknown';
    }

    private function format_datetime($value): string
    {
        if (!$value || $value === '0000-00-00 00:00:00') {
            return '';
        }

        $timestamp = strtotime((string) $value . ' UTC');

        if (!$timestamp) {
            return '';
        }

        if (!(bool) apply_filters('flights_tracker_times_are_utc', true)) {
            $timestamp = strtotime((string) $value);
        }

        $flight_date = wp_date('Y-m-d', $timestamp);
        $today = wp_date('Y-m-d');

        return $flight_date === $today ? wp_date('H:i', $timestamp) : wp_date('d/m/y H:i', $timestamp);
    }

    private function format_local_datetime($value): string
    {
        if (!$value || $value === '0000-00-00 00:00:00') {
            return '';
        }

        $datetime = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', (string) $value, wp_timezone());

        if (!$datetime) {
            return '';
        }

        $timestamp = $datetime->getTimestamp();
        $date = wp_date('Y-m-d', $timestamp);

        return $date === wp_date('Y-m-d') ? wp_date('H:i', $timestamp) : wp_date('d/m/y H:i', $timestamp);
    }

    private function date_range(string $from, string $to): array
    {
        $today = wp_date('Y-m-d');

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) {
            $from = $today;
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
            $to = $from;
        }

        if ($to < $from) {
            $to = $from;
        }

        return [
            'from' => $from,
            'to' => $to,
            'start' => $from . ' 00:00:00',
            'end' => gmdate('Y-m-d H:i:s', strtotime($to . ' 00:00:00 UTC') + DAY_IN_SECONDS),
        ];
    }

    private function range_label(array $range): string
    {
        if ($range['from'] === $range['to']) {
            return wp_date('d/m/y', strtotime($range['from'] . ' 00:00:00'));
        }

        return wp_date('d/m/y', strtotime($range['from'] . ' 00:00:00')) . ' - ' . wp_date('d/m/y', strtotime($range['to'] . ' 00:00:00'));
    }

    private function can_start_from_current_time(array $filters, array $range): bool
    {
        return $filters['query'] === ''
            && $range['from'] === wp_date('Y-m-d')
            && $range['to'] === wp_date('Y-m-d');
    }

    private function initial_page_anchor_time(): string
    {
        $anchor = current_datetime()->modify('-30 minutes');

        if ((bool) apply_filters('flights_tracker_times_are_utc', true)) {
            $anchor = $anchor->setTimezone(new DateTimeZone('UTC'));
        }

        return $anchor->format('Y-m-d H:i:s');
    }

    private function best_time_for_query(array $flight): string
    {
        $real = trim((string) ($flight['hora_real'] ?? ''));
        $scheduled = trim((string) ($flight['hora_programada'] ?? ''));

        return $real !== '' ? $real : $scheduled;
    }

    private function archive_departure_timestamp(array $flight): ?int
    {
        $real = trim((string) ($flight['hora_real'] ?? ''));
        $scheduled = trim((string) ($flight['hora_programada'] ?? ''));
        $value = $real !== '' ? $real : $scheduled;

        return $this->raw_datetime_timestamp($value);
    }

    private function snapshot_departure_timestamp(array $snapshot): ?int
    {
        $real = trim((string) ($snapshot['departure_real_time'] ?? ''));
        $scheduled = trim((string) ($snapshot['departure_scheduled_time'] ?? ''));
        $value = $real !== '' ? $real : $scheduled;

        return $this->raw_datetime_timestamp($value);
    }

    private function datetime_or_null($value): ?string
    {
        $value = trim((string) ($value ?? ''));

        if ($value === '' || $value === '0000-00-00 00:00:00') {
            return null;
        }

        return preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value) ? $value : null;
    }

    private function raw_datetime_timestamp($value): ?int
    {
        $value = $this->datetime_or_null($value);

        if (!$value) {
            return null;
        }

        if ((bool) apply_filters('flights_tracker_times_are_utc', true)) {
            $datetime = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $value, new DateTimeZone('UTC'));
        } else {
            $datetime = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $value, wp_timezone());
        }

        return $datetime ? $datetime->getTimestamp() : null;
    }

    private function site_design_css(): string
    {
        return <<<CSS
body:not(.wp-admin) header.wp-block-template-part .wp-block-navigation,
body:not(.wp-admin) header.wp-block-template-part .wp-block-site-title,
body:not(.wp-admin) header.wp-block-template-part .wp-block-navigation__responsive-container-open,
body:not(.wp-admin) header.wp-block-template-part .wp-block-navigation__responsive-container-close {
  display: none !important;
}

body:not(.wp-admin) .wp-site-blocks > footer.wp-block-template-part {
  display: none !important;
}

.ft-page-logo {
  margin: clamp(24px, 7vw, 80px) 0 clamp(12px, 3vw, 24px);
  text-align: center;
}

.ft-page-logo .custom-logo-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  text-decoration: none;
}

.ft-page-logo img {
  display: block;
  width: clamp(112px, 24vw, 190px);
  max-width: 100%;
  height: auto;
  object-fit: contain;
}

.ft-site-footer {
  box-sizing: border-box;
  width: min(1200px, calc(100% - clamp(40px, 8vw, 96px)));
  margin: clamp(64px, 10vw, 120px) auto clamp(24px, 5vw, 44px);
  color: inherit;
  font-size: clamp(14px, 2.2vw, 18px);
  text-align: center;
}

.ft-site-footer__text {
  margin: 0;
}
CSS;
    }

    private function site_logo_markup(string $class): string
    {
        $logo = get_custom_logo();

        if ($logo !== '') {
            return sprintf('<div class="%s">%s</div>', esc_attr($class), $logo);
        }

        $site_icon = get_site_icon_url(192);

        if (!$site_icon) {
            return '';
        }

        return sprintf(
            '<div class="%1$s"><a class="custom-logo-link" href="%2$s" rel="home"><img src="%3$s" alt="%4$s"></a></div>',
            esc_attr($class),
            esc_url(home_url('/')),
            esc_url($site_icon),
            esc_attr(get_bloginfo('name'))
        );
    }

    private function live_table(string $override = ''): string
    {
        $table = $this->sanitize_table_name($override);

        if ($table === '' && defined('FLIGHTS_TRACKER_LIVE_TABLE')) {
            $table = $this->sanitize_table_name((string) FLIGHTS_TRACKER_LIVE_TABLE);
        }

        if ($table === '') {
            $table = $this->sanitize_table_name((string) apply_filters('flights_tracker_live_table', self::LIVE_TABLE));
        }

        if ($table === '') {
            $table = self::LIVE_TABLE;
        }

        return implode('.', array_map(static function (string $part): string {
            return '`' . str_replace('`', '``', $part) . '`';
        }, explode('.', $table)));
    }

    private function sanitize_table_name(string $table): string
    {
        $table = trim($table);

        if ($table === '') {
            return '';
        }

        return preg_match('/^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)?$/', $table) ? $table : '';
    }

    private function saved_table(): string
    {
        global $wpdb;

        return $wpdb->prefix . 'flights_tracker_saved';
    }

    private function archived_table(): string
    {
        global $wpdb;

        return $wpdb->prefix . 'flights_tracker_archived';
    }
}

Flights_Tracker_Plugin::init();
